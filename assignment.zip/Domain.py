from UI import *
from Functions import *
from Tests import *

perform_tests()
start()